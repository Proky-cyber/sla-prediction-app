import streamlit as st
import joblib
import numpy as np

# Načtení modelu
model = joblib.load("sla_model.pkl")

# Titulek aplikace
st.title("🎯 Predikce porušení SLA")

# Vstupní formulář
ticket_volume = st.slider("📦 Počet ticketů", 10, 50, 25)
avg_response_time = st.slider("⏱️ Průměrná doba reakce (hod)", 1.0, 10.0, 4.0)
team_capacity = st.slider("👥 Kapacita týmu", 1, 20, 10)
incident_severity = st.selectbox("⚠️ Závažnost incidentu", [1, 2, 3])
day_of_week = st.selectbox("📅 Den v týdnu", {
    0: "Pondělí", 1: "Úterý", 2: "Středa", 3: "Čtvrtek",
    4: "Pátek", 5: "Sobota", 6: "Neděle"
})

# Tlačítko pro predikci
if st.button("🔍 Spustit predikci"):
    input_data = np.array([[ticket_volume, avg_response_time, team_capacity, incident_severity, day_of_week]])
    prediction = model.predict(input_data)[0]
    if prediction == 1:
        st.error("❌ Porušení SLA: Ano")
    else:
        st.success("✅ Porušení SLA: Ne")
